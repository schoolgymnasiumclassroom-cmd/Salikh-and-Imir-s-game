# English Detective

A free, browser-based educational game prototype for Grade 6.

## Included
- 5 mystery cases
- 5 missions per case
- Immediate feedback
- Score out of 100
- Clue collection
- Detective ranks
- Detective Report
- Print report
- QR code sharing

## Cases
1. The Missing Backpack — Past Simple + school vocabulary
2. The Dragon Mystery — descriptions + adjectives
3. The Storm Case — natural disasters + action verbs
4. The Airport Mystery — travel English
5. The Lost Explorer — geography + English

## Run locally
Open `index.html` in a browser.

The QR generator uses the free open-source `qrcode` package loaded from jsDelivr. Internet access is therefore needed for QR generation. The game itself is otherwise client-side.

## Publish for free
Upload the three files (`index.html`, `style.css`, `script.js`) to a public GitHub repository and enable GitHub Pages.

After publication, the QR button automatically encodes the published page URL.

## Important
This is intentionally a static first version. No accounts, database, paid API, or server are required.
