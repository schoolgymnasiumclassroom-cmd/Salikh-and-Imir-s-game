const cases = [
  {
    id:"backpack", number:"CASE 01", icon:"🎒", title:"The Missing Backpack",
    topic:"Past Simple + school vocabulary",
    intro:"A student’s backpack disappeared after school. Follow the clues and discover where it went.",
    missions:[
      {title:"Find the time clue", q:"Which word tells us that an action happened in the past?", choices:["tomorrow","yesterday","now","every day"], answer:1, clue:"The first clue says: YESTERDAY."},
      {title:"Read the evidence", q:"Yesterday, Mia ___ her classroom before she went home.", choices:["cleaned","cleans","clean"], answer:0, clue:"Mia cleaned the classroom. Check the places near the classroom."},
      {title:"Follow the action", q:"Which sentence is correct?", choices:["She go to the library.","She went to the library.","She goes to the library yesterday.","She going to the library."], answer:1, clue:"The library is the next place to investigate."},
      {title:"Question the witness", q:"Choose the correct question about yesterday.", choices:["Did you see the backpack?","Do you saw the backpack?","Did you saw the backpack?","Are you see the backpack?"], answer:0, clue:"The witness saw something near a blue locker."},
      {title:"Crack the final clue", q:"The witness says: “I ___ a blue backpack near the locker.”", choices:["see","saw","sees","seeing"], answer:1, clue:"CASE SOLVED: The backpack was found near the blue locker!"}
    ]
  },
  {
    id:"dragon", number:"CASE 02", icon:"🐉", title:"The Dragon Mystery",
    topic:"Descriptions + adjectives",
    intro:"A young dragon has vanished from a magical valley. Use English clues to discover its hiding place.",
    missions:[
      {title:"Identify the dragon", q:"Which adjective means “very big”?", choices:["tiny","enormous","quiet","young"], answer:1, clue:"The dragon is ENORMOUS."},
      {title:"Read the description", q:"The dragon has ___ wings.", choices:["two large","large two","two larges","large twos"], answer:0, clue:"Two large wings leave a trail in the grass."},
      {title:"Choose the clue", q:"Which sentence describes a place?", choices:["The dragon is green.","The cave is dark.","The dragon can fly.","The dragon is hungry."], answer:1, clue:"A DARK CAVE is the strongest location clue."},
      {title:"Complete the message", q:"The dragon is hiding ___ the cave.", choices:["in","on","at","between"], answer:0, clue:"Look INSIDE the cave."},
      {title:"Final description", q:"Which sentence is correct?", choices:["It has a long green tail.","It has green a long tail.","It have a long green tail.","It has a tail long green."], answer:0, clue:"CASE SOLVED: The dragon is safe inside the dark cave!"}
    ]
  },
  {
    id:"storm", number:"CASE 03", icon:"🌪️", title:"The Storm Case",
    topic:"Natural disasters + action verbs",
    intro:"A strange storm is approaching. Decode the weather evidence before the final warning.",
    missions:[
      {title:"Name the event", q:"A powerful column of air spins very fast. What is it?", choices:["drought","tornado","flood","avalanche"], answer:1, clue:"The first symbol is a TORNADO."},
      {title:"Choose the action", q:"Strong winds can ___ trees.", choices:["collapse","damage","irrigate","restore"], answer:1, clue:"The storm can DAMAGE trees and buildings."},
      {title:"Read the report", q:"Water covers roads and fields after heavy rain. This is a ___ .", choices:["flood","drought","hurricane","lightning"], answer:0, clue:"The river has overflowed: FLOOD."},
      {title:"Complete the warning", q:"People should stay inside if a severe storm ___ .", choices:["strike","strikes","striking","struck"], answer:1, clue:"The warning says: stay inside when the storm STRIKES."},
      {title:"Solve the forecast", q:"Which sentence gives a future prediction?", choices:["The storm hit yesterday.","The storm is here now.","The storm will arrive tonight.","The storm arrived last night."], answer:2, clue:"CASE SOLVED: The storm will arrive tonight. The safe plan is ready!"}
    ]
  },
  {
    id:"airport", number:"CASE 04", icon:"🧳", title:"The Airport Mystery",
    topic:"Travel English + functional language",
    intro:"A passenger’s suitcase has the wrong tag. Find the correct flight and solve the airport mystery.",
    missions:[
      {title:"Find the destination", q:"You are travelling by plane. Where do you go first?", choices:["airport","museum","stadium","library"], answer:0, clue:"The suitcase is at the AIRPORT."},
      {title:"Read the boarding clue", q:"“Flight 208 is ___ at Gate 6.”", choices:["boarding","board","boarded","boards"], answer:0, clue:"Gate 6 is now boarding."},
      {title:"Ask for help", q:"Which sentence is polite?", choices:["Give me my suitcase.","Where suitcase?","Could you help me, please?","You help me now."], answer:2, clue:"The airport assistant can help you."},
      {title:"Follow the luggage", q:"The suitcase is ___ the conveyor belt.", choices:["on","at","to","between"], answer:0, clue:"The suitcase is ON the conveyor belt."},
      {title:"Final announcement", q:"Choose the correct sentence.", choices:["The flight has delayed.","The flight has been delayed.","The flight been delayed.","The flight has delay."], answer:1, clue:"CASE SOLVED: The suitcase is safe and the passenger has the correct information!"}
    ]
  },
  {
    id:"explorer", number:"CASE 05", icon:"🌍", title:"The Lost Explorer",
    topic:"Geography + English",
    intro:"An explorer left a trail of English clues across the world. Find the final location.",
    missions:[
      {title:"Read the map clue", q:"Which place is the driest?", choices:["rainforest","desert","ocean","glacier"], answer:1, clue:"The first clue points to a DESERT."},
      {title:"Choose the direction", q:"The explorer walked from the village ___ the mountain.", choices:["towards","yesterday","quickly","because"], answer:0, clue:"The trail goes TOWARDS the mountain."},
      {title:"Climate clue", q:"Which place is usually very cold and covered with ice?", choices:["desert","rainforest","polar region","savanna"], answer:2, clue:"The next clue is in a POLAR REGION."},
      {title:"Connect the evidence", q:"The explorer took a jacket ___ the weather was cold.", choices:["but","because","or","so"], answer:1, clue:"BECAUSE connects the cold weather with the jacket."},
      {title:"Final location", q:"Which sentence is correct?", choices:["The explorer has reached the glacier.","The explorer have reached the glacier.","The explorer has reach the glacier.","The explorer reached the glacier tomorrow."], answer:0, clue:"CASE SOLVED: The explorer has reached the glacier!"}
    ]
  }
];

let state = {
  caseIndex:null, mission:0, score:0, correct:0, clues:[], answered:false,
  startedAt:null, mistakes:0
};

const app = document.getElementById("app");

function showHome(){
  app.innerHTML = `
    <section class="hero">
      <div>
        <div class="eyebrow">AN ENGLISH LANGUAGE ADVENTURE</div>
        <h1>Can you solve the case?</h1>
        <p class="lead">Become an English detective. Complete language missions, collect clues, crack the mystery and receive your personal Detective Report.</p>
        <div class="score-strip">
          <div class="stat">🎯 <b>5</b> missions per case</div>
          <div class="stat">🔎 <b>5</b> clues</div>
          <div class="stat">🏆 <b>100</b> points</div>
        </div>
      </div>
      <div class="hero-note">
        <div class="stamp">DETECTIVE ACADEMY</div>
        <div class="big">English is your evidence.</div>
        <p>Every correct answer reveals a clue. Collect enough evidence to solve the case.</p>
      </div>
    </section>

    <section>
      <div class="section-title">
        <div>
          <div class="eyebrow">CHOOSE YOUR CASE</div>
          <h2>Five mysteries. One detective.</h2>
        </div>
        <button class="secondary-btn" onclick="openQR()">📱 Share game</button>
      </div>
      <div class="case-grid">
        ${cases.map((c,i)=>`
          <article class="case-card">
            <div class="case-number">${c.number}</div>
            <div class="case-icon">${c.icon}</div>
            <h3>${c.title}</h3>
            <div class="topic">${c.topic}</div>
            <span class="difficulty">A2 • 5 missions</span>
            <button class="primary-btn start" onclick="startCase(${i})">Start case →</button>
          </article>
        `).join("")}
      </div>
    </section>
  `;
}

function startCase(index){
  state = {caseIndex:index, mission:0, score:0, correct:0, clues:[], answered:false, startedAt:Date.now(), mistakes:0};
  renderMission();
  window.scrollTo({top:0,behavior:"smooth"});
}

function renderMission(){
  const c = cases[state.caseIndex];
  const m = c.missions[state.mission];
  const pct = ((state.mission)/c.missions.length)*100;
  app.innerHTML = `
    <section class="game-wrap">
      <button class="secondary-btn back-link" onclick="showHome()">← All cases</button>
      <div class="game-head">
        <div class="game-title">
          <div class="game-icon">${c.icon}</div>
          <div>
            <div class="eyebrow">${c.number}</div>
            <h2>${c.title}</h2>
            <div class="muted">${c.topic}</div>
          </div>
        </div>
        <div class="progress-area">
          <div class="progress-top"><span>Mission ${state.mission+1} of ${c.missions.length}</span><span>${state.score}/100</span></div>
          <div class="progress"><span style="width:${pct}%"></span></div>
        </div>
      </div>

      <div class="mission-card">
        <div class="mission-label">MISSION ${String(state.mission+1).padStart(2,"0")} • ${m.title.toUpperCase()}</div>
        <div class="mission-title">${m.title}</div>
        <div class="question">${m.q}</div>
        <div class="choices">
          ${m.choices.map((x,i)=>`<button class="choice" id="choice-${i}" onclick="answer(${i})">${String.fromCharCode(65+i)}. ${x}</button>`).join("")}
        </div>
        <div id="feedback" class="feedback" aria-live="polite"></div>
        <div id="clue" class="clue-reveal" style="display:none">
          <strong>🔎 CLUE FOUND</strong>
          <span id="clueText"></span>
        </div>
        <div class="mission-actions">
          <div class="score-strip" style="margin:0">
            <div class="stat">🔎 Clues: <b>${state.clues.length}</b></div>
            <div class="stat">✓ Correct: <b>${state.correct}</b></div>
          </div>
          <button class="primary-btn" id="nextBtn" style="display:none" onclick="nextMission()">Continue →</button>
        </div>
      </div>
    </section>
  `;
}

function answer(selected){
  if(state.answered) return;
  state.answered = true;
  const c = cases[state.caseIndex], m = c.missions[state.mission];
  const feedback = document.getElementById("feedback");
  const clue = document.getElementById("clue");
  const clueText = document.getElementById("clueText");

  document.querySelectorAll(".choice").forEach((btn,i)=>{
    btn.disabled=true;
    if(i===m.answer) btn.classList.add("correct");
  });

  if(selected===m.answer){
    state.score += 20;
    state.correct++;
    state.clues.push(m.clue);
    feedback.className="feedback show good";
    feedback.innerHTML="✓ Correct! You found the evidence.";
  }else{
    state.mistakes++;
    document.getElementById("choice-"+selected).classList.add("wrong");
    feedback.className="feedback show bad";
    feedback.innerHTML=`✗ Not this time. The correct answer is <b>${m.choices[m.answer]}</b>. The clue is still available.`;
    state.clues.push(m.clue);
  }
  clue.style.display="block";
  clueText.textContent=m.clue;
  document.getElementById("nextBtn").style.display="inline-block";
}

function nextMission(){
  if(state.mission < cases[state.caseIndex].missions.length-1){
    state.mission++;
    state.answered=false;
    renderMission();
    window.scrollTo({top:0,behavior:"smooth"});
  }else{
    showReport();
  }
}

function showReport(){
  const c=cases[state.caseIndex];
  const total=c.missions.length;
  const accuracy=Math.round((state.correct/total)*100);
  const seconds=Math.max(1,Math.round((Date.now()-state.startedAt)/1000));
  const mins=Math.floor(seconds/60), secs=seconds%60;
  let rank="Rookie Detective";
  if(state.score===100) rank="Master Detective";
  else if(state.score>=80) rank="Senior Detective";
  else if(state.score>=60) rank="Field Detective";
  else if(state.score>=40) rank="Junior Detective";

  app.innerHTML=`
    <section class="report">
      <button class="secondary-btn back-link" onclick="showHome()">← Choose another case</button>
      <div class="report-paper">
        <div class="report-top">
          <div>
            <div class="eyebrow">OFFICIAL DETECTIVE REPORT</div>
            <h2>${c.icon} ${c.title}</h2>
            <div class="muted">${c.topic}</div>
          </div>
          <div class="stamp-box">CASE<br>SOLVED</div>
        </div>

        <div style="margin-top:25px">
          <div class="muted">FINAL SCORE</div>
          <div class="big-score">${state.score}<span style="font-size:20px;color:var(--muted)"> / 100</span></div>
        </div>

        <div class="report-grid">
          <div class="report-stat"><div class="label">Accuracy</div><div class="value">${accuracy}%</div></div>
          <div class="report-stat"><div class="label">Correct answers</div><div class="value">${state.correct} / ${total}</div></div>
          <div class="report-stat"><div class="label">Clues collected</div><div class="value">${state.clues.length}</div></div>
          <div class="report-stat"><div class="label">Time</div><div class="value">${mins}:${String(secs).padStart(2,"0")}</div></div>
        </div>

        <div class="eyebrow">EVIDENCE COLLECTED</div>
        <div class="clues">${state.clues.map((x,i)=>`<span class="clue-pill">🔎 ${i+1}. ${x}</span>`).join("")}</div>

        <div class="rank">
          <div class="label">DETECTIVE RANK</div>
          <div class="name">${rank}</div>
          <div style="color:#cbd5e1;margin-top:5px">${state.mistakes===0 ? "Perfect investigation. No mistakes." : `${state.mistakes} mistake${state.mistakes===1?"":"s"} during the investigation.`}</div>
        </div>

        <div class="report-actions">
          <button class="primary-btn" onclick="startCase(${state.caseIndex})">🔄 Try again</button>
          <button class="secondary-btn" onclick="showHome()">🗂️ Choose another case</button>
          <button class="secondary-btn" onclick="openQR()">📱 Share game</button>
          <button class="secondary-btn" onclick="window.print()">🖨️ Print report</button>
        </div>
      </div>
    </section>
  `;
  window.scrollTo({top:0,behavior:"smooth"});
}

function openQR(){
  const modal=document.getElementById("qrModal");
  const box=document.getElementById("qrBox");
  const url=document.getElementById("currentUrl");
  modal.classList.remove("hidden");
  modal.setAttribute("aria-hidden","false");
  url.textContent=location.href;
  box.innerHTML="";
  if(window.QRCode){
    QRCode.toCanvas(location.href,{width:205,margin:2,errorCorrectionLevel:"M"},function(err,canvas){
      if(err){ box.innerHTML='<div class="qr-loading">QR could not be created.</div>'; return; }
      box.appendChild(canvas);
    });
  }else{
    box.innerHTML='<div class="qr-loading">QR library is loading. Try again.</div>';
  }
}
function closeQR(){
  document.getElementById("qrModal").classList.add("hidden");
  document.getElementById("qrModal").setAttribute("aria-hidden","true");
}
async function copyLink(){
  const status=document.getElementById("copyStatus");
  try{
    await navigator.clipboard.writeText(location.href);
    status.textContent="✓ Link copied.";
  }catch(e){
    status.textContent="Copy is unavailable here. Select the link above.";
  }
}
document.getElementById("qrModal").addEventListener("click",e=>{
  if(e.target.id==="qrModal") closeQR();
});
document.addEventListener("keydown",e=>{
  if(e.key==="Escape") closeQR();
});
showHome();
